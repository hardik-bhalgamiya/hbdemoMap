//
//  AutocompletionTableView.m
//
//  Created by Gushin Arseniy on 11.03.12.
//  Copyright (c) 2012 Arseniy Gushin. All rights reserved.
//

#import "AutocompletionTableView.h"

@interface AutocompletionTableView () 
@property (nonatomic, strong) NSArray *suggestionOptions; // of selected NSStrings 
@property (nonatomic, strong) UITextField *textField; // will set automatically as user enters text
@property (nonatomic, strong) UIFont *cellLabelFont; // will copy style from assigned textfield
@property (nonatomic,strong) NSString *key;
@end

@implementation AutocompletionTableView

@synthesize suggestionsDictionary = _suggestionsDictionary;
@synthesize suggestionOptions = _suggestionOptions;
@synthesize textField = _textField;
@synthesize cellLabelFont = _cellLabelFont;
@synthesize options = _options;
@synthesize key = key;

#pragma mark - Initialization
- (UITableView *)initWithTextField:(UITextField *)textField inViewController:(UIViewController *) parentViewController withOptions:(NSDictionary *)options
{
    //set the options first
   
    self.options = options;
    key = [options valueForKey:@"key"];
    // frame must align to the textfield 
    CGRect frame = CGRectMake(textField.frame.origin.x, textField.frame.origin.y + textField.frame.size.height , textField.frame.size.width, 120);
    //    CGRect frame = CGRectMake(textField.frame.origin.x, textField.frame.origin.y+textField.frame.size.height+60, textField.frame.size.width, 120);

    // save the font info to reuse in cells
    self.cellLabelFont = textField.font;
    
    self = [super initWithFrame:frame style:UITableViewStylePlain];
            
    self.delegate = self;
    self.dataSource = self;
    self.scrollEnabled = YES;
    
    // turn off standard correction
    textField.autocorrectionType = UITextAutocorrectionTypeNo;
    
    // to get rid of "extra empty cell" on the bottom
    // when there's only one cell in the table
    UIView *v = [[UIView alloc] initWithFrame:CGRectMake(0, textField.frame.origin.y + textField.frame.size.height, textField.frame.size.width, 1)];
    v.backgroundColor = [UIColor clearColor];
    [self setTableFooterView:v];
    self.hidden = YES;  
    [parentViewController.view addSubview:self];

    return self;
}

#pragma mark - Logic staff
- (BOOL) substringIsInDictionary:(NSString *)subString
{
    NSMutableArray *tmpArray = [NSMutableArray array];
    NSRange range;
    
    if (_autoCompleteDelegate && [_autoCompleteDelegate respondsToSelector:@selector(autoCompletion:suggestionsFor:)]) {
        self.suggestionsDictionary = [_autoCompleteDelegate autoCompletion:self suggestionsFor:subString];
    }
   // if ([key isEqualToString:@"country"]) {
        for (NSString *tmpString in [self.suggestionsDictionary valueForKey:@"name"])
        {
            range = ([[self.options valueForKey:ACOCaseSensitive] isEqualToNumber:[NSNumber numberWithInt:1]]) ? [tmpString rangeOfString:subString] : [tmpString rangeOfString:subString options:NSCaseInsensitiveSearch];
            if (range.location != NSNotFound)
                [tmpArray addObject:tmpString];
        }
//    }
//    else if([key isEqualToString:@"state"])
//    {
//        for (NSString *tmpString in [self.suggestionsDictionary valueForKey:@"state"])
//        {
//            range = ([[self.options valueForKey:nil] isEqualToNumber:[NSNumber numberWithInt:1]]) ? [tmpString rangeOfString:subString] : [tmpString rangeOfString:subString options:NSCaseInsensitiveSearch];
//            if (range.location != NSNotFound)
//                [tmpArray addObject:tmpString];
//        }
//    }
//    else if([key isEqualToString:@"city"])
//    {
//        for (NSString *tmpString in [self.suggestionsDictionary valueForKey:@"city"])
//        {
//            range = ([[self.options valueForKey:nil] isEqualToNumber:[NSNumber numberWithInt:1]]) ? [tmpString rangeOfString:subString] : [tmpString rangeOfString:subString options:NSCaseInsensitiveSearch];
//            if (range.location != NSNotFound)
//                [tmpArray addObject:tmpString];
//        }
//    }
    if ([tmpArray count]>0)
    {
        self.suggestionOptions = tmpArray;
        return YES;
    }
    return NO;

    /*
    NSMutableArray *tmpArray = [NSMutableArray array];
    NSRange range;
    
    if (_autoCompleteDelegate && [_autoCompleteDelegate respondsToSelector:@selector(autoCompletion:suggestionsFor:)]) {
        self.suggestionsDictionary = [_autoCompleteDelegate autoCompletion:self suggestionsFor:subString];
    }
   
    for (NSString *tmpString in [self.suggestionsDictionary valueForKey:@"zip_code"])
    {
        range = ([[self.options valueForKey:ACOCaseSensitive] isEqualToNumber:[NSNumber numberWithInt:1]]) ? [tmpString rangeOfString:subString] : [tmpString rangeOfString:subString options:NSCaseInsensitiveSearch];
        if (range.location != NSNotFound)
            [tmpArray addObject:tmpString];
    }
    for (NSString *tmpString in [self.suggestionsDictionary valueForKey:@"state_name"])
    {
        range = ([[self.options valueForKey:ACOCaseSensitive] isEqualToNumber:[NSNumber numberWithInt:1]]) ? [tmpString rangeOfString:subString] : [tmpString rangeOfString:subString options:NSCaseInsensitiveSearch];
        if (range.location != NSNotFound)
            [tmpArray addObject:tmpString];
    }
    if ([tmpArray count]>0)
    {
        self.suggestionOptions = tmpArray;
        return YES;
    }
    return NO;*/
}
//- (BOOL) substringIsInDictionary:(NSString *)subString key:(NSString *)key
//{
//    NSMutableArray *tmpArray = [NSMutableArray array];
//    NSRange range;
//    
//    if (_autoCompleteDelegate && [_autoCompleteDelegate respondsToSelector:@selector(autoCompletion:suggestionsFor:)]) {
//        self.suggestionsDictionary = [_autoCompleteDelegate autoCompletion:self suggestionsFor:subString];
//    }
//    if ([key isEqualToString:@"zip_code"]) {
//        for (NSString *tmpString in [self.suggestionsDictionary valueForKey:@"zip_code"])
//        {
//            range = ([[self.options valueForKey:ACOCaseSensitive] isEqualToNumber:[NSNumber numberWithInt:1]]) ? [tmpString rangeOfString:subString] : [tmpString rangeOfString:subString options:NSCaseInsensitiveSearch];
//            if (range.location != NSNotFound)
//                [tmpArray addObject:tmpString];
//        }
//    }
//   else if([key isEqualToString:@"state_name"])
//   {
//       for (NSString *tmpString in [self.suggestionsDictionary valueForKey:@"state_name"])
//       {
//           range = ([[self.options valueForKey:ACOCaseSensitive] isEqualToNumber:[NSNumber numberWithInt:1]]) ? [tmpString rangeOfString:subString] : [tmpString rangeOfString:subString options:NSCaseInsensitiveSearch];
//           if (range.location != NSNotFound)
//               [tmpArray addObject:tmpString];
//       }
//
//   }
//        if ([tmpArray count]>0)
//    {
//        self.suggestionOptions = tmpArray;
//        return YES;
//    }
//    return NO;
//}
#pragma mark - Table view data source
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.suggestionOptions.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSString *AutoCompleteRowIdentifier = @"AutoCompleteRowIdentifier";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:AutoCompleteRowIdentifier];
    if (cell == nil) 
    {
        cell = [[UITableViewCell alloc] 
                 initWithStyle:UITableViewCellStyleDefault reuseIdentifier:AutoCompleteRowIdentifier];
    }
    tableView.layer.cornerRadius=2;
    tableView.backgroundColor=[UIColor clearColor];
    cell.backgroundColor=[UIColor colorWithHexValue:@"#202F46"];
    
    if ([self.options valueForKey:ACOUseSourceFont]) 
    {
        cell.textLabel.font = [self.options valueForKey:ACOUseSourceFont];
    } else 
    {
        cell.textLabel.font = self.cellLabelFont;
    }
    cell.textLabel.adjustsFontSizeToFitWidth = NO;
    cell.textLabel.textColor=[UIColor whiteColor];
    cell.textLabel.text = [self.suggestionOptions objectAtIndex:indexPath.row];

    return cell;
}

#pragma mark - Table view delegate
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [self.textField setText:[self.suggestionOptions objectAtIndex:indexPath.row] ];
    
    if (_autoCompleteDelegate && [_autoCompleteDelegate respondsToSelector:@selector(autoCompletion:didSelectAutoCompleteSuggestionWithIndex:)]) {
        [_autoCompleteDelegate autoCompletion:self didSelectAutoCompleteSuggestionWithIndex:indexPath.row];
    }
    [self hideOptionsView];
}

#pragma mark - UITextField delegate
- (void)textFieldValueChanged:(UITextField *)textField
{
    self.textField = textField;
    NSString *curString = textField.text;

    if (![curString length])
    {
        [self hideOptionsView];
        return;
    } else if ([self substringIsInDictionary:curString]){
        [self showOptionsView];
        [self reloadData];
    }
    else [self hideOptionsView];
}

#pragma mark - Options view control
- (void)showOptionsView
{
//    if([key isEqualToString:@"what"]){
        CGRect frame = CGRectMake(self.textField.frame.origin.x+3, 180, self.textField.frame.size.width, 120);
        self.frame = frame;
  //  }
       self.hidden = NO;
}

- (void) hideOptionsView
{
    self.hidden = YES;
}
- (void) ResetFrames
{
    if (!self.hidden)
    {
       // if([key isEqualToString:@"what"]){
            CGRect frame = CGRectMake(self.textField.frame.origin.x+3, 180, self.textField.frame.size.width, 120);
            self.frame = frame;
      //  }
        
    }
}
@end
