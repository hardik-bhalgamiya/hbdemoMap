//
//  CommonFunctions.h
//  GrabMySpace
//
//  Created by Keshav on 05/12/13.
//  Copyright (c) 2013 Keshav. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "AFNetworkReachabilityManager.h"
#import "METoast.h"
#import <MapKit/MapKit.h>



@interface CommonFunctions : NSObject

+(BOOL) checkIsEmpty:(NSString *) s;
+(NSString *) myTrim:(NSString *) string;
+(NSString *)removeWhiteSpaces :(NSString *)stringValue;
+(BOOL)networkConnected;
+ (UIImage*) ellipseWithImage:(UIImage *) originalImage;
+(UIImage *)imageWithImage:(UIImage *)image scaledToSize:(CGSize)newSize;
+(void)saveImage:(UIImage *)Selectedimage scaledToSize:(CGSize)newSize imageName:(NSString*)imgName;
+ (void)removeImage:(NSString *)filename;
+ (NSString *)documentsPathForFileName:(NSString *)name;
+(void)showAlertMessage : (NSString *)bodyString;
+(BOOL)IsValidEmail:(NSString *)checkString;
+(void)showNoNetworkError;
+(void)showToastMessage :(NSString *)message;
+(UIImage *) userBackgroundImage;
+(void)showNoInternetErrorMessage;
+(NSString *)stringByStrippingHTML:(NSString*)str;
+(NSAttributedString *)strikeString:(NSString*)str;
+(BOOL)isKeyBoardInDisplay;
+(NSMutableString *)strMutableFromArray:(NSMutableArray *)arr withSeperater:(NSString *)saperator withKey:(NSString*)ObjectKey;
+(NSMutableString *)strMutableFromArray:(NSMutableArray *)arr withSeperater:(NSString *)saperator;
+(CLLocationCoordinate2D) getLocationFromAddressString: (NSString*) addressStr ;
+(NSString*)getAddressFromLatLong : (NSString *)latLng ;
+(NSString *)encodeToBase64String:(UIImage *)image;

+(void)TextFieldStyle:(UITextField*)txtField;
+(void)TextViewFieldStyle:(UITextView*)txtViewField;
+(void)ViewStyle:(UIView*)yourview;

+(void)ButtonStyle:(UIButton*)button;

+(void)ViewStyleWithBorder:(UIView*)yourview;
+(void)ViewStyleWithLine:(UIView*)yourview;
+(void)ServiceErrorResponse:(NSError*)Error;
+(void)newtextfieldStyle:(UITextField *)newtextfield;
+(NSString*)remaningTime:(NSDate*)startDate endDate:(NSDate*)endDate;

+(NSInteger)randomValueBetween:(NSInteger)min and:(NSInteger)max;
@end
