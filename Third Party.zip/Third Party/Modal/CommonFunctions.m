//
//  CommonFunctions.m
//  GrabMySpace
//
//  Created by Keshav on 05/12/13.
//  Copyright (c) 2013 Keshav. All rights reserved.
//

#import "CommonFunctions.h"
#import <MapKit/MKPlacemark.h>
#import <QuartzCore/CALayer.h>
#import "AFNetworking.h"

@implementation CommonFunctions

+(BOOL) checkIsEmpty:(NSString *) s
{
    if ([s isEqual:[NSNull null]]) return YES;
    s = [self myTrim:[NSString stringWithFormat:@"%@",s]];
    if([s isEqualToString:@"(null)"]) s = @"";
    return ([s isEqualToString:@""])?YES:NO;
}
+(NSString *) myTrim:(NSString *) string {
    return [string stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
}
+(NSString *)removeWhiteSpaces :(NSString *)stringValue{
    NSString *trimmedString = [stringValue stringByTrimmingCharactersInSet:
                               [NSCharacterSet whitespaceCharacterSet]];
    return trimmedString;
}
+(BOOL)networkConnected {
    return [AFNetworkReachabilityManager sharedManager].reachable;
}
+ (UIImage*) ellipseWithImage:(UIImage *) originalImage
{
    CGRect circleRect=CGRectMake(0,0,50,50);
    CGSize size = circleRect.size;
    UIGraphicsBeginImageContext(size);
    CGContextRef context = UIGraphicsGetCurrentContext();
    
    CGContextSaveGState(context);
    CGRect clipRect=CGRectMake(circleRect.origin.x,circleRect.origin.y, size.width, size.height-8);
    CGContextSetLineWidth(context, 8);
    CGMutablePathRef path=CGPathCreateMutable();
    CGPathAddEllipseInRect(path, NULL, clipRect);
    CGContextAddPath(context, path);
    CGContextClip(context);
    
    UIImage *image = [self imageWithImage:originalImage scaledToSize:size];
    [image drawInRect:clipRect];
    
    image = UIGraphicsGetImageFromCurrentImageContext();
    CGContextRestoreGState(context);
    UIGraphicsEndImageContext();
    return image;
}
+(UIImage *)imageWithImage:(UIImage *)image scaledToSize:(CGSize)newSize {
    UIGraphicsBeginImageContextWithOptions(newSize, NO, 0.0);
    [image drawInRect:CGRectMake(0, 0, newSize.width, newSize.height)];
    UIImage *newImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return newImage;
}

+(void)saveImage:(UIImage *)Selectedimage scaledToSize:(CGSize)newSize imageName:(NSString*)imgName
{
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths objectAtIndex:0] ;
    NSLog(@"document Directory : %@",documentsDirectory);
    NSString *savedImagePath = [documentsDirectory stringByAppendingPathComponent:[NSString stringWithFormat:@"%@.png",imgName]];
    UIImage *image = Selectedimage; // imageView is where you are displaying image after selecting one from UIImagePicker
    NSData *imageData = UIImagePNGRepresentation(image);
    [imageData writeToFile:savedImagePath atomically:NO];
}

+ (void)removeImage:(NSString *)filename
{
    NSFileManager *fileManager = [NSFileManager defaultManager];
    NSString *documentsPath = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0];
    
    NSString *filePath = [documentsPath stringByAppendingPathComponent:filename];
    NSError *error;
    BOOL success = [fileManager removeItemAtPath:filePath error:&error];
    if (success) {
//        UIAlertView *removedSuccessFullyAlert = [[UIAlertView alloc] initWithTitle:@"Congratulations:" message:@"Successfully removed" delegate:self cancelButtonTitle:@"Close" otherButtonTitles:nil];
//        [removedSuccessFullyAlert show];
        NSLog(@"Successfull remove image from document directory");
    }
    else
    {
        NSLog(@"Could not delete file -:%@ ",[error localizedDescription]);
    }
}


+ (NSString *)documentsPathForFileName:(NSString *)name
{
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,NSUserDomainMask, YES);
    NSString *documentsPath = [paths objectAtIndex:0];
    
    return [documentsPath stringByAppendingPathComponent:name];
}


+(void)showAlertMessage:(NSString *)bodyString {
    UIAlertView *alertView = [[UIAlertView alloc]initWithTitle:nil message:bodyString delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
    alertView.tag=999;
    [alertView show];
}

//+(void)showNoInternetErrorMessage
//{
//    [[TWMessageBarManager sharedInstance] showMessageWithTitle:@"Error "
//                                                   description:@"No Internet Connection !!"
//                                                          type:TWMessageBarMessageTypeError
//                                                statusBarStyle:UIStatusBarStyleLightContent
//                                                      callback:nil];
//}


+(BOOL)IsValidEmail:(NSString *)checkString
{
    BOOL stricterFilter = YES;
    NSString *stricterFilterString = @"[A-Z0-9a-z\\._%+-]+@([A-Za-z0-9-]+\\.)+[A-Za-z]{2,4}";
    NSString *laxString = @".+@([A-Za-z0-9]+\\.)+[A-Za-z]{2}[A-Za-z]*";
    NSString *emailRegex = stricterFilter ? stricterFilterString : laxString;
    NSPredicate *emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", emailRegex];
    return [emailTest evaluateWithObject:checkString];
}

+(void)showNoNetworkError {
    METoastAttribute *attr = [[METoastAttribute alloc] init];
    attr.location = METoastLocationTop;
    [METoast setToastAttribute:attr];
    [METoast toastWithMessage:@"No Internet Connection"];
}
+(void)showToastMessage :(NSString *)message {
    METoastAttribute *attr = [[METoastAttribute alloc] init];
    attr.location = METoastLocationTop;
    [METoast setToastAttribute:attr];
    [METoast toastWithMessage:message];
}
+(UIImage *) userBackgroundImage {
    NSString * documentsDirectoryPath = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0];
   // NSString *str=[documentsDirectoryPath stringByAppendingString:kLogin.username];
      // NSString *str=[NSString stringWithString:UserImage];
    UIImage * result = [UIImage imageWithContentsOfFile:[NSString stringWithFormat:@"%@/profile.png", documentsDirectoryPath]];
    
    NSLog(@"%@ DOCUMENT",documentsDirectoryPath);
    return result;
}
+(NSString *)stringByStrippingHTML:(NSString*)str
{
    NSRange r;
    while ((r = [str rangeOfString:@"<[^>]+> " options:NSRegularExpressionSearch]).location     != NSNotFound)
    {
        str = [str stringByReplacingCharactersInRange:r withString:@""];
    }
    return str;
}
+(NSAttributedString *)strikeString:(NSString*)str
{
    NSMutableAttributedString *attributeString = [[NSMutableAttributedString alloc] initWithString:str];
    [attributeString addAttribute:NSStrikethroughStyleAttributeName
                            value:@2
                            range:NSMakeRange(0, [attributeString length])];
    [attributeString addAttributes:@{NSStrikethroughStyleAttributeName: @(NSUnderlineStyleSingle)
                                     , NSStrikethroughColorAttributeName: [UIColor darkGrayColor]
                                     , NSBackgroundColorAttributeName: [UIColor clearColor]} range:NSMakeRange(0, [attributeString length])];
    return attributeString;
}
+(BOOL)isKeyBoardInDisplay  {
    
    BOOL isExists = NO;
    for (UIWindow *keyboardWindow in [[UIApplication sharedApplication] windows]){
        if ([[keyboardWindow description] hasPrefix:@"<UITextEffectsWindow"] == YES) {
            isExists = YES;
        }
    }
    
    return isExists;
}

+(NSString *)encodeToBase64String:(UIImage *)image {
    return [UIImagePNGRepresentation(image) base64EncodedStringWithOptions:NSDataBase64Encoding64CharacterLineLength];
}

+(NSMutableString *)strMutableFromArray:(NSMutableArray *)arr withSeperater:(NSString *)saperator withKey:(NSString*)ObjectKey
{
    NSMutableString *strResult = [NSMutableString string];
    
    for (int j=0; j<[arr count]; j++)
    {
        NSString *strBar = [[arr objectAtIndex:j] valueForKey:ObjectKey];
        [strResult appendString:[NSString stringWithFormat:@"%@",strBar]];
        if (j != [arr count]-1)
        {
            [strResult appendString:[NSString stringWithFormat:@"%@",saperator]];
        }
    }
    return strResult;
}
+(NSMutableString *)strMutableFromArray:(NSMutableArray *)arr withSeperater:(NSString *)saperator
{
    NSMutableString *strResult = [NSMutableString string];
    
    for (int j=0; j<[arr count]; j++)
    {
        NSString *strBar = [arr objectAtIndex:j];
        [strResult appendString:[NSString stringWithFormat:@"%@",strBar]];
        if (j != [arr count]-1)
        {
            [strResult appendString:[NSString stringWithFormat:@"%@",saperator]];
        }
    }
    return strResult;
}
+(CLLocationCoordinate2D) getLocationFromAddressString: (NSString*) addressStr {
    double latitude = 0, longitude = 0;
    NSString *esc_addr =  [addressStr stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    NSString *req = [NSString stringWithFormat:@"http://maps.google.com/maps/api/geocode/json?sensor=false&address=%@", esc_addr];
    NSString *result = [NSString stringWithContentsOfURL:[NSURL URLWithString:req] encoding:NSUTF8StringEncoding error:NULL];
    if (result) {
        NSScanner *scanner = [NSScanner scannerWithString:result];
        if ([scanner scanUpToString:@"\"lat\" :" intoString:nil] && [scanner scanString:@"\"lat\" :" intoString:nil]) {
            [scanner scanDouble:&latitude];
            if ([scanner scanUpToString:@"\"lng\" :" intoString:nil] && [scanner scanString:@"\"lng\" :" intoString:nil]) {
                [scanner scanDouble:&longitude];
            }
        }
    }
    CLLocationCoordinate2D center;
    center.latitude=latitude;
    center.longitude = longitude;
    NSLog(@"View Controller get Location Logitute : %f",center.latitude);
    NSLog(@"View Controller get Location Latitute : %f",center.longitude);
    return center;
}
+(NSString*)getAddressFromLatLong : (NSString *)latLng {
    //  NSString *string = [[Address.text stringByAppendingFormat:@"+%@",cityTxt.text] stringByAppendingFormat:@"+%@",addressText];
    NSString *esc_addr =  [latLng stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    
    NSString *req = [NSString stringWithFormat:@"http://maps.google.com/maps/api/geocode/json?sensor=false&address=%@", esc_addr];
    NSString *result = [NSString stringWithContentsOfURL:[NSURL URLWithString:req] encoding:NSUTF8StringEncoding error:NULL];
    NSMutableDictionary *data = [NSJSONSerialization JSONObjectWithData:[result dataUsingEncoding:NSUTF8StringEncoding]options:NSJSONReadingMutableContainers error:nil];
    NSMutableArray *dataArray = (NSMutableArray *)[data valueForKey:@"results" ];
    if (dataArray.count == 0) {
        UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"Error" message:@"Please Enter a valid address" delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil, nil];
        [alert show];
    }else{
        for (id firstTime in dataArray) {
            NSString *jsonStr1 = [firstTime valueForKey:@"formatted_address"];
            return jsonStr1;
        }
    }
    
    return nil;
}

+(void)ServiceErrorResponse:(NSError*)Error{
    NSInteger statusCode = Error.code;
    if(statusCode == -1001) {
        // request timed out
        [CommonFunctions showToastMessage:@" Request timed out "];
        
        
    } else if (statusCode == -1009 || statusCode || -1004) {
        // no internet connectivity
        [CommonFunctions showToastMessage:@" No internet connectivity "];
    }
}

+(void)TextFieldStyle:(UITextField*)txtField{
    txtField.backgroundColor=[UIColor clearColor];
    txtField.layer.borderWidth=1;
    txtField.layer.borderColor=[UIColor lightGrayColor].CGColor;
}
+(void)TextViewFieldStyle:(UITextView*)txtViewField{
    txtViewField.backgroundColor=[UIColor clearColor];
    txtViewField.layer.borderWidth=1;
    txtViewField.layer.borderColor=[UIColor lightGrayColor].CGColor;
    
}
+(void)ViewStyle:(UIView*)yourview{
    yourview.backgroundColor=[UIColor clearColor];
    yourview.layer.borderWidth=1;
    yourview.layer.borderColor=[UIColor lightGrayColor].CGColor;
}
+(void)ViewStyleWithBorder:(UIView*)yourview{
    yourview.layer.cornerRadius=5;
    yourview.layer.cornerRadius=5;
    yourview.layer.borderWidth=2;
    yourview.layer.borderColor=[UIColor colorWithHexValue:Button_Color].CGColor;
}
+(void)ViewStyleWithLine:(UIView*)yourview{
    yourview.layer.borderWidth=1;
    yourview.layer.borderColor=[UIColor colorWithHexValue:Line_Color].CGColor;
}
+(void)ButtonStyle:(UIButton *)button{
    button.layer.cornerRadius=5;
    button.layer.borderWidth=1;
    button.layer.borderColor=[[UIColor lightGrayColor] colorWithAlphaComponent:0.5].CGColor;
   
}

+(void)newtextfieldStyle:(UITextField *)newtextfield{
    newtextfield.layer.cornerRadius=5;
    newtextfield.layer.borderWidth=1;
    newtextfield.layer.borderColor=[[UIColor lightGrayColor] colorWithAlphaComponent:0.5].CGColor;
    
    UIView *paddingView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 5, 20)];
    newtextfield.leftView = paddingView;
    newtextfield.leftViewMode = UITextFieldViewModeAlways;
}
+(void)setSpaceInTextField:(UITextField*)textfield{
    UIView *paddingView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 5, 20)];
    textfield.leftView = paddingView;
    textfield.leftViewMode = UITextFieldViewModeAlways;
}

+(NSString*)remaningTime:(NSDate*)startDate endDate:(NSDate*)endDate{
    
    NSDateComponents *components;
    NSInteger days;
    NSInteger hour;
    NSInteger minutes;
    NSString *durationString;
    
    
    components = [[NSCalendar currentCalendar] components: NSCalendarUnitDay|NSCalendarUnitHour|NSCalendarUnitMinute
                                                 fromDate: startDate toDate: endDate options: 0];
    days = [components day];
    hour=[components hour];
    minutes=[components minute];
    
    if(days>0){
        
        if(days>1){
            durationString=[NSString stringWithFormat:@"%d days",days];
        }
        else{
            durationString=[NSString stringWithFormat:@"%d day",days];
            
        }
        return durationString;
    }
    
    if(hour>0){
        
        if(hour>1){
            durationString=[NSString stringWithFormat:@"%d hours",hour];
        }
        else{
            durationString=[NSString stringWithFormat:@"%d hour",hour];
            
        }
        return durationString;
    }
    
    if(minutes>0){
        
        if(minutes>1){
            durationString=[NSString stringWithFormat:@"%d minutes",minutes];
        }
        else{
            durationString=[NSString stringWithFormat:@"%d minute",minutes];
            
        }
        return durationString;
    }
    
    return @"";
}
+ (NSInteger)randomValueBetween:(NSInteger)min and:(NSInteger)max {
    return (NSInteger)(min + arc4random_uniform(max - min + 1));
}
@end
