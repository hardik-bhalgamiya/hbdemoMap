//
//  Constant.h
//  gym
//
//  Created by keshav infotech on 1/9/15.
//  Copyright (c) 2015 keshav infotech. All rights reserved.
//

#ifndef gym_Constant_h
#define gym_Constant_h

#define SYSTEM_VERSION_EQUAL_TO(v)                  ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] == NSOrderedSame)
#define SYSTEM_VERSION_GREATER_THAN(v)              ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] == NSOrderedDescending)
#define SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(v)  ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] != NSOrderedAscending)
#define SYSTEM_VERSION_LESS_THAN(v)                 ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] == NSOrderedAscending)
#define SYSTEM_VERSION_LESS_THAN_OR_EQUAL_TO(v)     ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] != NSOrderedDescending)


#pragma mark - Device

//#define IS_IPAD                         ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPad)
//#define IS_IPHONE_5                     ( fabs( ( double )[ [ UIScreen mainScreen ] bounds ].size.height - ( double )568 ) < DBL_EPSILON )
//#define IS_IPHONE_6 (fabs((double)[[UIScreen mainScreen]bounds].size.height - (double)667) < DBL_EPSILON)
//#define IS_IPHONE_6_PLUS (fabs((double)[[UIScreen mainScreen]bounds].size.height - (double)736) < DBL_EPSILON)

#define IS_IPAD (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad)
#define IS_IPHONE (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPhone)
#define IS_RETINA ([[UIScreen mainScreen] scale] >= 2.0)

#define SCREEN_WIDTH ([[UIScreen mainScreen] bounds].size.width)
#define SCREEN_HEIGHT ([[UIScreen mainScreen] bounds].size.height)
#define SCREEN_MAX_LENGTH (MAX(SCREEN_WIDTH, SCREEN_HEIGHT))
#define SCREEN_MIN_LENGTH (MIN(SCREEN_WIDTH, SCREEN_HEIGHT))

#define IS_IPHONE_4_OR_LESS (IS_IPHONE && SCREEN_MAX_LENGTH < 568.0)
#define IS_IPHONE_5 (IS_IPHONE && SCREEN_MAX_LENGTH == 568.0)
#define IS_IPHONE_6 (IS_IPHONE && SCREEN_MAX_LENGTH == 667.0)
#define IS_IPHONE_6P (IS_IPHONE && SCREEN_MAX_LENGTH == 736.0)

#pragma mark - Screen Size

//#define     SCREEN_WIDTH        [ [ UIScreen mainScreen ] bounds ].size.width
//#define     SCREEN_HEIGHT       [ [ UIScreen mainScreen ] bounds ].size.height

//#define SCREEN_WIDTH ((([UIApplication sharedApplication].statusBarOrientation == UIInterfaceOrientationPortrait) || ([UIApplication sharedApplication].statusBarOrientation == UIInterfaceOrientationPortraitUpsideDown)) ? [[UIScreen mainScreen] bounds].size.width : [[UIScreen mainScreen] bounds].size.height)
//#define SCREEN_HEIGHT ((([UIApplication sharedApplication].statusBarOrientation == UIInterfaceOrientationPortrait) || ([UIApplication sharedApplication].statusBarOrientation == UIInterfaceOrientationPortraitUpsideDown)) ? [[UIScreen mainScreen] bounds].size.height : [[UIScreen mainScreen] bounds].size.width)



//#define SIA_URL @"http://tapalwale.com/sia/webs/index_function.php"
//#define SIA_URL_Img @"http://tapalwale.com/sia/uploads/"

#define SIA_URL @"http://websitesample.in/sia/webs/index_function.php"
#define SIA_URL_Img @"http://websitesample.in/sia/uploads/"


// for database
#pragma mark Database

#define kDATA_STORAGE_PATH [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0]
#define kDB_NAME           @"SIA.sqlite"
#define kDB_PATH           [kDATA_STORAGE_PATH stringByAppendingPathComponent:kDB_NAME]
#define kSHARED_INSTANCE    [SharedDataManager sharedDbManager]
#define kDATABASE           [kSHARED_INSTANCE database]



// Default color Name for App

#define Header_Color @"#AF301B"
#define Button_Color @"#33A582"
#define TextFied_BackgroundColor @"#FFE3B9"
#define Line_Color @"#FE9900"
#define DarkText_color @"#683300"
#define LabelColor @"#942824"

// image path from local directory
#define DOCUMENTDIRECTORYPATH [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0]

#pragma mark - Activity Indicator

#define ShowNetworkActivityIndicator() [UIApplication sharedApplication].networkActivityIndicatorVisible = YES
#define HideNetworkActivityIndicator() [UIApplication sharedApplication].networkActivityIndicatorVisible = NO


#define ShowHUD [MBProgressHUD showHUDAddedTo:self.view animated:YES]
#define HideHUD [MBProgressHUD hideAllHUDsForView:self.view animated:YES]

#define storyboardNameIphone  [UIStoryboard storyboardWithName:@"Main" bundle:nil]
#define storyboardNameIpad  [UIStoryboard storyboardWithName:@"Main_iPad" bundle:nil]

#pragma mark - User Details

#define UserId     [[NSUserDefaults standardUserDefaults] valueForKey:@"uid"]
#define UserEmail  [[NSUserDefaults standardUserDefaults] valueForKey:@"userEmail"]
#define UserName  [[NSUserDefaults standardUserDefaults] valueForKey:@"userName"]
#define UserProfile  [[NSUserDefaults standardUserDefaults] valueForKey:@"userProfile"]

#define isEventSponsor  [[NSUserDefaults standardUserDefaults] valueForKey:@"isEventSponsor"]


#define UserFirstName   [[NSUserDefaults standardUserDefaults] valueForKey:@"fname"]
#define UserLastName   [[NSUserDefaults standardUserDefaults] valueForKey:@"lname"]
#define UserContact_no  [[NSUserDefaults standardUserDefaults] valueForKey:@"contact_no"]
#define UserContract  [[NSUserDefaults standardUserDefaults] valueForKey:@"contract"]

#define UserPassword  [[NSUserDefaults standardUserDefaults] valueForKey:@"password"]

#define userPincode  [[NSUserDefaults standardUserDefaults] valueForKey:@"userPincode"]
#define userLoginType  [[NSUserDefaults standardUserDefaults] valueForKey:@"userLoginType"]


#define userType  [[NSUserDefaults standardUserDefaults] valueForKey:@"userType"]



#endif
