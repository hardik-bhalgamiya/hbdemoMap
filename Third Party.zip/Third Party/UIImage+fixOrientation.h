//
//  UIImage+fixOrientation.h
//  XLME
//
//  Created by KAlpesh Shah on 10/05/16.
//  Copyright © 2016 HB. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImage_fixOrientation : UIImage

@end
