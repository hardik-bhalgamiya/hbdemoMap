//
//  UIImage+fixOrientation.m
//  XLME
//
//  Created by KAlpesh Shah on 10/05/16.
//  Copyright © 2016 HB. All rights reserved.
//

#import "UIImage+fixOrientation.h"

@implementation UIImage_fixOrientation

@end
